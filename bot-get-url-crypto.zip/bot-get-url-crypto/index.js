const { execFile, exec  } = require('child_process');
const fs = require('fs');
const express = require("express");
const bodyParser = require("body-parser");
const router = express.Router();
const app = express();

//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.listen(3000,() => {
    console.log("Started on PORT 3000");
})

router.post("/url-crypto",(request, res) => {

    console.log(request.body);

    fs.writeFileSync('url-crypt.json', JSON.stringify(request.body, null, '\t'));

    try {
        fs.unlinkSync("../../luna-bot/dash/url-crypt.json");
    } catch (e) {
        console.log(e);
    }

    fs.copyFileSync("url-crypt.json", "../../luna-bot/dash/url-crypt.json");
    
    exec('cd "../../luna-bot/" && git status', function(err, response){
        console.log("git status");
        if(!err){
            console.log(response);
        }else {
            console.log(err);
        }

        exec('cd "../../luna-bot/" && git add .', function(err, response){
            console.log("git status");
            if(!err){
                console.log(response);
            }else {
                console.log(err);
            }
            exec('cd "../../luna-bot/" && git commit -m "publicacao"', function(err, response){
                console.log("git commit -m \"publicacao\"");
                if(!err){
                    console.log(response);
                }else {
                    console.log(err);
                }
                exec('cd "../../luna-bot/" && git pull origin main', function(err, response){
                    console.log("git pull origin main");
                    if(!err){
                        console.log(response);
                    }else {
                        console.log(err);
                    }
                    exec('cd "../../luna-bot/" && git push origin main', function(err, response){
                        console.log("git push origin main");
                        if(!err){
                            console.log(response);
                        }else {
                            console.log(err);
                        }
                        exec('cd "../../luna-bot/" && git status', function(err, response){
                            console.log("git status");
                            if(!err){
                                console.log(response);
                            }else {
                                console.log(err);
                            }
                        });
                    });        
                }); 
            });
        });

    });

    res.end("");
});

// add router in the Express app.
app.use("/", router);


