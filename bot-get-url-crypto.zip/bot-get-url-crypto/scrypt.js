(function(XHR) {
    "use strict";
    window.urlCrypto = {} ;

    var open = XHR.prototype.open;
    var send = XHR.prototype.send;

    XHR.prototype.open = function(method, url, async, user, pass) {
        this._url = url;
        open.call(this, method, url, async, user, pass);
    };

    XHR.prototype.send = function(data) {
        var self = this;
        var oldOnReadyStateChange;
        var url = this._url;

        function onReadyStateChange() {
            if(self.readyState == 4 /* complete */) {
               console.log(this._url)

               if (
                   this._url.indexOf("/user/me") > -1
                   || this._url.indexOf("/user/roi") > -1
                   || this._url.indexOf("/hero/active") > -1
                   || this._url.indexOf("/hero/boss") > -1
                   || this._url.indexOf("/battle/boss") > -1
                ) {
                   var urlSplited = this._url.split("?");
                   window.urlCrypto[urlSplited[0]] = urlSplited[1];
                   console.log(window.urlCrypto);
               }

            }

            if(oldOnReadyStateChange) {
                oldOnReadyStateChange();
            }
        }

        /* Set xhr.noIntercept to true to disable the interceptor for a particular call */
        if(!this.noIntercept) {            
            if(this.addEventListener) {
                this.addEventListener("readystatechange", onReadyStateChange, false);
            } else {
                oldOnReadyStateChange = this.onreadystatechange; 
                this.onreadystatechange = onReadyStateChange;
            }
        }

        send.call(this, data);
    }
})(XMLHttpRequest);

/*
/api/user/me
/api/user/roi
/api/hero/active
/hero/boss
/battle/boss
*/